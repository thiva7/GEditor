<svg {{ $attributes }} viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" class="⚙     as-9n as-z as-10 as-11 as-8a as-13 as-14 as-47 as-3 ⚙9ssu6z">
    <path fill="#EBF1F7" d="M0 0h32v32H0z"></path>
    <g clip-path="url(#bi_bancontact__a_:r83:_0)">
        <path d="M8.164 21.448c3.918 0 5.877-2.612 7.836-5.224H3v5.224h5.164Z" fill="url(#bi_bancontact__b_:r83:_1)"></path>
        <path d="M23.836 11c-3.918 0-5.877 2.612-7.836 5.224h13V11h-5.164Z" fill="url(#bi_bancontact__c_:r83:_2)"></path>
    </g>
    <defs>
        <linearGradient id="bi_bancontact__b_:r83:_1" x1="5.629" y1="19.077" x2="15.139" y2="15.544" gradientUnits="userSpaceOnUse">
            <stop stop-color="#005AB9"></stop>
            <stop offset="1" stop-color="#1E3764"></stop>
        </linearGradient>
        <linearGradient id="bi_bancontact__c_:r83:_2" x1="16.787" y1="16.677" x2="26.885" y2="13.232" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FBA900"></stop>
            <stop offset="1" stop-color="#FFD800"></stop>
        </linearGradient>
        <clipPath id="bi_bancontact__a_:r83:_0">
            <path fill="#fff" transform="translate(3 11)" d="M0 0h26v10.447H0z"></path>
        </clipPath>
    </defs>
</svg>
