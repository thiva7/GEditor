<aside id="main-aside" class="mt-14 w-64 h-screen md:flex hidden flex-col justify-between border-e border-neutral bg-background-secondary fixed top-0 left-0 rtl:right-0 z-10">
    <x-navigation.sidebar-links />
</aside>
