<x-admin-layout>
    <x-slot name="title">
        {{ __('Dashboard') }}
    </x-slot>
    <div class="content">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900">{{ __('Admin Dashboard') }}</h1>
            <p class="text-secondary-600 dark:text-secondary-500">{{ __('Welcome to the admin panel') }}</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div class="content-box">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-secondary-600 dark:text-secondary-500">{{ __('Total Clients') }}</p>
                        <p class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ $clientsCount ?? 0 }}</p>
                    </div>
                    <div class="bg-primary-100 dark:bg-primary-900/20 w-12 h-12 rounded-lg flex items-center justify-center">
                        <i class="ri-group-line text-2xl text-primary-400"></i>
                    </div>
                </div>
            </div>
            <div class="content-box">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-secondary-600 dark:text-secondary-500">{{ __('Total Orders') }}</p>
                        <p class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ $ordersCount ?? 0 }}</p>
                    </div>
                    <div class="bg-success-100 dark:bg-success-900/20 w-12 h-12 rounded-lg flex items-center justify-center">
                        <i class="ri-shopping-cart-2-line text-2xl text-success-400"></i>
                    </div>
                </div>
            </div>
            <div class="content-box">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-secondary-600 dark:text-secondary-500">{{ __('Total Revenue') }}</p>
                        <p class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">
                            <x-money :amount="$revenue ?? 0" />
                        </p>
                    </div>
                    <div class="bg-primary-100 dark:bg-primary-900/20 w-12 h-12 rounded-lg flex items-center justify-center">
                        <i class="ri-money-dollar-circle-line text-2xl text-primary-400"></i>
                    </div>
                </div>
            </div>
            <div class="content-box">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-secondary-600 dark:text-secondary-500">{{ __('Pending Tickets') }}</p>
                        <p class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ $ticketsCount ?? 0 }}</p>
                    </div>
                    <div class="bg-warning-100 dark:bg-warning-900/20 w-12 h-12 rounded-lg flex items-center justify-center">
                        <i class="ri-question-answer-line text-2xl text-warning-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-admin-layout>

