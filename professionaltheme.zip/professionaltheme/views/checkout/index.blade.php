<x-app-layout>
    <x-slot name="title">
        {{ __('Checkout') }}
    </x-slot>
    <div class="content">
        <x-success />
        <livewire:checkout />
    </div>
</x-app-layout>

