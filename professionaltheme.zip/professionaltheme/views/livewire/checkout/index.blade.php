<div class="max-w-4xl mx-auto">
    <div class="content-box mb-6">
        <h1 class="text-2xl font-bold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('Checkout') }}</h1>
        <p class="text-secondary-600 dark:text-secondary-500">{{ __('Review your order and complete your purchase') }}</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 space-y-6">
            @if($cart && count($cart) > 0)
                @foreach($cart as $item)
                    <div class="content-box">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-x-4">
                                @if(isset($item['image']) && $item['image'] !== 'null')
                                    <img src="{{ $item['image'] }}" alt="{{ $item['name'] }}" class="w-16 h-16 rounded-lg object-cover">
                                @endif
                                <div>
                                    <h3 class="font-semibold text-secondary-900 dark:text-secondary-900">{{ $item['name'] }}</h3>
                                    <p class="text-sm text-secondary-600 dark:text-secondary-500">
                                        <x-money :amount="$item['price']" />
                                    </p>
                                </div>
                            </div>
                            <button wire:click="removeFromCart({{ $item['id'] }})" class="button button-danger-outline">
                                <i class="ri-delete-bin-line"></i>
                            </button>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="content-box text-center py-12">
                    <i class="ri-shopping-cart-line text-6xl text-secondary-400 mb-4"></i>
                    <h3 class="text-xl font-semibold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('Your cart is empty') }}</h3>
                    <p class="text-secondary-600 dark:text-secondary-500 mb-4">{{ __('Add some products to get started') }}</p>
                    <a href="{{ route('index') }}" class="button button-primary">
                        {{ __('Browse Products') }}
                    </a>
                </div>
            @endif
        </div>

        <div class="lg:col-span-1">
            <div class="content-box sticky top-4">
                <h3 class="text-lg font-semibold text-secondary-900 dark:text-secondary-900 mb-4">{{ __('Order Summary') }}</h3>
                <div class="space-y-3 mb-4">
                    <div class="flex justify-between text-sm">
                        <span class="text-secondary-600 dark:text-secondary-500">{{ __('Subtotal') }}</span>
                        <span class="font-medium text-secondary-900 dark:text-secondary-900">
                            <x-money :amount="$subtotal ?? 0" />
                        </span>
                    </div>
                    <div class="flex justify-between text-sm">
                        <span class="text-secondary-600 dark:text-secondary-500">{{ __('Tax') }}</span>
                        <span class="font-medium text-secondary-900 dark:text-secondary-900">
                            <x-money :amount="$tax ?? 0" />
                        </span>
                    </div>
                    <hr class="border-secondary-200 dark:border-secondary-200">
                    <div class="flex justify-between">
                        <span class="font-semibold text-secondary-900 dark:text-secondary-900">{{ __('Total') }}</span>
                        <span class="font-bold text-lg text-primary-400">
                            <x-money :amount="$total ?? 0" />
                        </span>
                    </div>
                </div>
                @if($cart && count($cart) > 0)
                    <a href="{{ route('checkout.config') }}" class="button button-primary w-full">
                        {{ __('Continue to Payment') }}
                    </a>
                @endif
            </div>
        </div>
    </div>
</div>

