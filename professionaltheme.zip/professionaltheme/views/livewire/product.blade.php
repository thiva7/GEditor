<div class="md:col-span-1 col-span-3">
    <div class="content-box h-full flex flex-col hover:shadow-lg transition-shadow duration-200">
        <div class="flex gap-x-3 items-center mb-4">
            @if ($product->image !== 'null')
                <img src="{{ $product->image }}" alt="{{ $product->name }}" class="w-14 h-14 rounded-lg object-cover"
                    onerror="this.style.display='none';">
            @endif
            <div class="flex-1">
                <h3 class="text-lg font-semibold text-secondary-900 dark:text-secondary-900">
                    {{ $product->name }}
                </h3>
                <p class="text-primary-400 font-medium">
                    <x-money :amount="$product->price()" showFree="true" />
                </p>
            </div>
        </div>
        <div class="prose dark:prose-invert text-sm mb-4 flex-1">
            @markdownify($product->description)
        </div>
        <div class="pt-4 mt-auto">
            @if ($product->stock_enabled && $product->stock <= 0)
                <button class="button button-secondary w-full opacity-50 cursor-not-allowed" disabled>
                    {{ __('Out of stock') }}
                </button>
            @else
                <button class="button w-full @if ($added) button-success @else button-primary @endif"
                    wire:click="addToCart">
                    @if ($added)
                        <i class="ri-check-line mr-2"></i> {{ __('Added to cart') }}
                    @else
                        <i class="ri-shopping-cart-2-line mr-2"></i> {{ __('Add to cart') }}
                    @endif
                </button>
            @endif
        </div>
    </div>
</div>

