<x-app-layout title="{{ __('Edit profile') }}" clients>
    <x-success />
    <div class="content">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div class="lg:col-span-1">
                <div class="content-box">
                    <div class="flex gap-x-2 items-center mb-4">
                        <div class="bg-primary-400 w-8 h-8 flex items-center justify-center rounded-lg text-white">
                            <i class="ri-account-circle-line"></i>
                        </div>
                        <h3 class="font-semibold text-lg text-secondary-900 dark:text-secondary-900">{{ __('My Account') }}</h3>
                    </div>
                    <div class="flex flex-col gap-2">
                        <a href="{{ route('clients.profile') }}"
                            class="px-3 py-2 rounded-lg text-sm font-medium bg-primary-50 dark:bg-primary-900/20 text-primary-400 border-l-4 border-primary-400">
                            {{ __('My Details') }}
                        </a>
                        @if (config('settings::credits'))
                            <a href="{{ route('clients.credits') }}"
                                class="px-3 py-2 rounded-lg text-sm font-medium text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                {{ __('Credits') }}
                            </a>
                        @endif
                        <a href="{{ route('clients.api.index') }}"
                            class="px-3 py-2 rounded-lg text-sm font-medium text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                            {{ __('Account API') }}
                        </a>
                        @if (config('settings::affiliate'))
                            <a href="{{ route('clients.affiliate') }}"
                                class="px-3 py-2 rounded-lg text-sm font-medium text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                {{ __('Affiliate') }}
                            </a>
                        @endif
                    </div>
                </div>
            </div>
            <div class="lg:col-span-3">
                <div class="content-box">
                    <h1 class="text-xl font-semibold text-secondary-900 dark:text-secondary-900 mb-6">{{ __('My Details') }}</h1>
                    <form method="POST" action="{{ route('clients.profile.update') }}" class="space-y-6">
                        @csrf
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <x-input label="{{ __('First name') }}" type="text" name="first_name" id="first_name"
                                value="{{ Auth::user()->first_name }}" required icon="ri-user-3-line" />
                            <x-input label="{{ __('Last name') }}" type="text" name="last_name" id="last_name"
                                value="{{ Auth::user()->last_name }}" required icon="ri-user-3-line" />
                        </div>
                        <x-input label="{{ __('Email') }}" type="email" name="email" id="email"
                            value="{{ Auth::user()->email }}" required icon="ri-at-line" />
                        @if(config('settings::requiredClientDetails_address') == 1)
                            <x-input label="{{ __('Address') }}" type="text" name="address" id="address"
                                value="{{ Auth::user()->address }}" icon="ri-home-4-line" />
                        @endif
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            @if(config('settings::requiredClientDetails_city') == 1)
                                <x-input label="{{ __('City') }}" type="text" name="city" id="city"
                                    value="{{ Auth::user()->city }}" icon="ri-building-2-line" />
                            @endif
                            @if(config('settings::requiredClientDetails_zip') == 1)
                                <x-input label="{{ __('Zip') }}" type="text" name="zip" id="zip"
                                    value="{{ Auth::user()->zip }}" icon="ri-building-2-line" />
                            @endif
                        </div>
                        @if(config('settings::requiredClientDetails_country') == 1)
                            <x-input type="select" label="{{ __('Country') }}" name="country" id="country">
                                @foreach (App\Classes\Constants::countries() as $key => $country)
                                    <option value="{{ $key }}" @if(Auth::user()->country == $key) selected @endif>
                                        {{ $country }}
                                    </option>
                                @endforeach
                            </x-input>
                        @endif
                        <div class="flex justify-end">
                            <button type="submit" class="button button-primary">
                                {{ __('Save Changes') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

