<x-app-layout clients title="{{ __('Home') }}">
    <x-success />
    <div class="content">
        <div class="mb-6">
            <div class="content-box bg-gradient-to-r from-primary-400 to-primary-300 text-white">
                <div class="flex items-center gap-x-4">
                    <div class="flex-shrink-0">
                        <img class="w-16 h-16 rounded-lg" src="https://www.gravatar.com/avatar/{{ md5(Auth::user()->email) }}?s=200&d=mp" alt="{{ Auth::user()->name }}" />
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold">{{ __('Welcome back') }}, {{ Auth::user()->name }}</h1>
                        <p class="text-primary-50">{{ __('Manage your services and invoices from here') }}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2">
                <div class="content-box">
                    <h2 class="text-xl font-semibold text-secondary-900 dark:text-secondary-900 mb-4">{{ __('Recent Activity') }}</h2>
                    <div class="space-y-4">
                        <p class="text-secondary-600 dark:text-secondary-500">{{ __('No recent activity') }}</p>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-1">
                <div class="content-box">
                    <div class="flex items-center gap-x-2 mb-4">
                        <div class="bg-primary-400 w-8 h-8 flex items-center justify-center rounded-lg text-white">
                            <i class="ri-bill-line"></i>
                        </div>
                        <h3 class="text-lg font-semibold text-secondary-900 dark:text-secondary-900">{{ __('Pending Invoices') }}</h3>
                    </div>
                    <div class="space-y-3">
                        @forelse ($invoices as $invoice)
                            <div class="p-3 rounded-lg border border-secondary-200 dark:border-secondary-200 hover:bg-secondary-50 dark:hover:bg-secondary-200 cursor-pointer transition-colors duration-200" onclick="window.location.href='{{ route('clients.invoice.show', $invoice->id) }}'">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center gap-x-3">
                                        <div class="bg-primary-100 dark:bg-primary-900/20 w-10 h-10 rounded-lg flex items-center justify-center">
                                            <i class="ri-bill-fill text-primary-400"></i>
                                        </div>
                                        <div>
                                            <p class="font-medium text-secondary-900 dark:text-secondary-900">{{ __('Invoice') }} #{{ $invoice->id }}</p>
                                            <p class="text-sm text-secondary-500 dark:text-secondary-400">
                                                <x-money :amount="$invoice->total()" />
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @empty
                            <div class="text-center py-6">
                                <i class="ri-checkbox-circle-line text-4xl text-success-400 mb-2"></i>
                                <p class="text-secondary-600 dark:text-secondary-500 font-medium">{{ __('No pending invoices') }}</p>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

