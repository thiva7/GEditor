<x-app-layout title="{{ $announcement->title }}" description='{{ strip_tags(Str::markdown(nl2br(Stevebauman\Purify\Facades\Purify::clean($announcement->announcement)))) }}'>
    
    <div class="content">
        <div class="content-box max-w-4xl mx-auto">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-6 border-b border-secondary-200 dark:border-secondary-200">
                <h1 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900">{{ $announcement->title }}</h1>
                <div class="flex items-center gap-x-5 text-sm text-secondary-500 dark:text-secondary-400">
                    <p class="flex items-center gap-x-2">
                        <i class="ri-calendar-line"></i>
                        {{ $announcement->created_at->format('d/m/Y') }}
                    </p>
                    <p class="flex items-center gap-x-2">
                        <i class="ri-time-line"></i>
                        {{ $announcement->created_at->format('H:i') }}
                    </p>
                </div>
            </div>
            <div class="prose dark:prose-invert max-w-none">
                @markdownify($announcement->announcement)
            </div>
        </div>
    </div>

</x-app-layout>

