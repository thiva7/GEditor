<x-app-layout title="Announcements">
    <div class="content">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('Announcements') }}</h1>
            <p class="text-secondary-600 dark:text-secondary-500">{{ __('Stay up to date with our latest news and updates') }}</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse ($announcements as $announcement)
                <div class="content-box h-full flex flex-col hover:shadow-lg transition-shadow duration-200">
                    <div class="mb-4">
                        <h3 class="text-xl font-semibold text-secondary-900 dark:text-secondary-900 mb-2">
                            <a href="{{ route('announcements.view', $announcement->id) }}" class="hover:text-primary-400 transition-colors duration-200">
                                {{ $announcement->title }}
                            </a>
                        </h3>
                        <div class="flex items-center gap-x-4 text-sm text-secondary-500 dark:text-secondary-400">
                            <span class="flex items-center gap-x-1">
                                <i class="ri-calendar-line"></i>
                                {{ $announcement->created_at->format('d/m/Y') }}
                            </span>
                            <span class="flex items-center gap-x-1">
                                <i class="ri-time-line"></i>
                                {{ $announcement->created_at->format('H:i') }}
                            </span>
                        </div>
                    </div>
                    <div class="prose dark:prose-invert text-sm mb-4 flex-1 line-clamp-3">
                        @markdownify(Str::limit($announcement->announcement, 150))
                    </div>
                    <div class="pt-4 mt-auto">
                        <a href="{{ route('announcements.view', $announcement->id) }}" class="button button-primary-outline w-full text-center">
                            {{ __('Read More') }}
                        </a>
                    </div>
                </div>
            @empty
                <div class="col-span-full">
                    <div class="content-box text-center py-12">
                        <i class="ri-megaphone-line text-6xl text-secondary-400 mb-4"></i>
                        <h3 class="text-xl font-semibold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('No Announcements') }}</h3>
                        <p class="text-secondary-600 dark:text-secondary-500">{{ __('There are no announcements at this time.') }}</p>
                    </div>
                </div>
            @endforelse
        </div>

        @if ($announcements->hasPages())
            <div class="mt-8">
                {{ $announcements->links() }}
            </div>
        @endif
    </div>
</x-app-layout>

