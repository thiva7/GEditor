<x-app-layout title="{{ __('Terms of Service') }}">
    <div class="content">
        <div class="content-box max-w-4xl mx-auto">
            <h1 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900 mb-6">{{ __('Terms of Service') }}</h1>
            <div class="prose dark:prose-invert max-w-none">
                @if(config('settings::tos'))
                    @markdownify(config('settings::tos'))
                @else
                    <p class="text-secondary-600 dark:text-secondary-500">{{ __('Terms of Service have not been set.') }}</p>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>

