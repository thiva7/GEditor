<x-app-layout description="{{ $category->description ?? null }}" title="{{ $category->name ?? __('Products') }}">
    <x-success />
    <script>
        function removeElement(element) {
            element.remove();
            this.error = true;
        }
    </script>
    <div class="content">
        <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
            @if ($categories->count() > 0)
                <div class="lg:col-span-1">
                    <div class="content-box sticky top-4">
                        <div class="flex gap-x-2 items-center mb-4">
                            <div class="bg-primary-400 w-8 h-8 flex items-center justify-center rounded-lg text-white">
                                <i class="ri-list-indefinite"></i>
                            </div>
                            <h3 class="font-semibold text-lg text-secondary-900 dark:text-secondary-900">{{ __('Categories') }}</h3>
                        </div>
                        <div class="flex flex-col gap-2">
                            @foreach ($categories as $categoryItem)
                                @php $hasActiveChild = false; @endphp
                                @if ($categoryItem->children->count() > 0)
                                    @foreach ($categoryItem->children as $childCategory)
                                        @if ($category->name == $childCategory->name)
                                            @php $hasActiveChild = true; @endphp
                                        @endif
                                    @endforeach
                                @endif
                                <div class="flex flex-col gap-1 group">
                                    @if ($categoryItem->products()->where('hidden', false)->count() > 0 || $categoryItem->children->count() > 0)
                                        <a href="{{ route('products', $categoryItem->slug) }}"
                                            class="px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 @if ($category->name == $categoryItem->name || $hasActiveChild) bg-primary-50 dark:bg-primary-900/20 text-primary-400 border-l-4 border-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                                            {{ $categoryItem->name }}
                                        </a>
                                    @endif
                                    @if($categoryItem->children->count() > 0)
                                        <div class="flex flex-col gap-1 ml-4 @if(!$hasActiveChild) hidden @endif group-hover:flex transition-all duration-200">
                                            @foreach ($categoryItem->children as $childCategory)
                                                <a href="{{ route('products', $childCategory->slug) }}"
                                                    class="px-3 py-1.5 rounded-lg text-sm @if ($category->name == $childCategory->name) bg-primary-50 dark:bg-primary-900/20 text-primary-400 border-l-4 border-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                                                    {{ $childCategory->name }}
                                                </a>
                                            @endforeach
                                        </div>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif

            <div class="@if ($categories->count() > 0) lg:col-span-3 @endif">
                <div class="content-box mb-6">
                    <div class="flex flex-col sm:flex-row gap-4 items-start">
                        @if($category->image)
                            <img src="/storage/categories/{{ $category->image }}" class="w-20 h-20 rounded-lg object-cover" />
                        @endif
                        <div class="flex-1">
                            <h1 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900 mb-2">{{ $category->name }}</h1>
                            <div class="prose dark:prose-invert max-w-none">
                                @markdownify($category->description)
                            </div>
                        </div>
                    </div>
                </div>

                @if($category->children->count() > 0)
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                        @foreach($category->children as $childCat)
                            <div class="content-box h-full flex flex-col hover:shadow-lg transition-shadow duration-200">
                                <div class="flex items-center gap-x-3 mb-4">
                                    @if($childCat->image)
                                        <img src="/storage/categories/{{ $childCat->image }}" class="w-14 h-14 rounded-lg object-cover" onerror="removeElement(this);" />
                                    @endif
                                    <div>
                                        <h3 class="font-semibold text-lg text-secondary-900 dark:text-secondary-900">{{ $childCat->name }}</h3>
                                    </div>
                                </div>
                                <div class="prose dark:prose-invert text-sm mb-4 flex-1">@markdownify($childCat->description)</div>
                                <div class="pt-4 mt-auto">
                                    <a href="{{ route('products', $childCat->slug) }}"
                                        class="button button-primary w-full text-center">
                                        {{ __('Browse Category') }}
                                    </a>
                                </div>
                            </div>
                        @endforeach
                    </div>
                @endif

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    @foreach ($category->products()->where('hidden', false)->with('prices')->orderBy('order')->get() as $product)
                        <livewire:product :product="$product" />
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</x-app-layout>

