@unless ($breadcrumbs->isEmpty())
    <nav class="mb-4">
        <ol class="flex flex-wrap items-center gap-2 text-sm">
            @foreach ($breadcrumbs as $breadcrumb)
                @if ($loop->first)
                    <a href="{{ $breadcrumb->url }}" class="text-secondary-600 dark:text-secondary-500 hover:text-primary-400 transition-colors duration-200">
                        <i class="ri-home-4-line"></i>
                    </a>
                    <span class="text-secondary-400 dark:text-secondary-500">/</span>
                @elseif (!is_null($breadcrumb->url))
                    <a href="{{ $breadcrumb->url }}" class="text-secondary-600 dark:text-secondary-500 hover:text-primary-400 transition-colors duration-200"
                        title="{{ $breadcrumb->title }}">
                        {{ $breadcrumb->title }}
                    </a>
                    @if(!$loop->last)
                        <span class="text-secondary-400 dark:text-secondary-500">/</span>
                    @endif
                @else
                    <span class="text-secondary-900 dark:text-secondary-900 font-medium">{{ $breadcrumb->title }}</span>
                @endif
            @endforeach
        </ol>
    </nav>
@endunless

