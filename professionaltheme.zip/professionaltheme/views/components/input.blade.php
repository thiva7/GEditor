@if ($type == 'checkbox')
    <div @isset($class) class="{{ $class }}" @endisset>
        <div class="flex items-start">
            <div class="flex items-center h-5">
                <input id="{{ $id ?? $name }}" type="checkbox"
                    @isset($value) value={{ $value }} @endisset
                    @isset($checked) {{ $checked ? 'checked' : '' }} @endisset
                    name={{ $name }}
                    autocomplete="@isset($autocomplete) {{ $autocomplete }} @else {{ $type }} @endisset"
                    @isset($disabled) {{ $disabled ? 'disabled' : '' }} @endisset
                    {{ $attributes->except('class') }}
                    class="w-4 h-4 border border-secondary-300 dark:border-secondary-600 rounded bg-white dark:bg-secondary-100 text-primary-400 focus:ring-2 focus:ring-primary-400 focus:ring-offset-2 ring-offset-white dark:ring-offset-secondary-100"
                    @isset($required) {{ $required ? 'required' : '' }} @endisset>
            </div>
            <label for="{{ $id ?? $name }}"
                class="ml-2 text-sm font-medium text-secondary-700 dark:text-secondary-600">{!! $label !!}</label>
        </div>
        @error($name)
            <label for="{{ $id ?? $name }}" class="text-sm text-danger-400 mt-1 block">{{ $message }}</label>
        @enderror
    </div>
@elseif($type == 'color')
    <div @isset($class) class={{ $class }} @endisset>
        {{ $slot }}
        @isset($label)
            <label for="{{ $id ?? $name }}" class="form-label">{!! $label !!}</label>
        @endisset
        <div class="relative">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <input type={{ $type }}
                @isset($placeholder) placeholder={{ $placeholder }} @endisset
                name={{ $name }}
                autocomplete="@isset($autocomplete) {{ $autocomplete }} @else {{ $type }} @endisset"
                @isset($value) value={{ $value }} @else value="{{ old($name) }}" @endisset
                id={{ $id ?? $name }}
                {{ $attributes->except('class') }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-input @isset($icon) pl-10 @endisset">
        </div>
        @error($name)
            <label for="{{ $id ?? $name }}" class="text-sm text-danger-400 mt-1 block">{{ $message }}</label>
        @enderror
    </div>
@elseif($type == 'select')
    <div @isset($class) class="{{ $class }}" @endisset>
        @isset($label)
            <label for="{{ $id ?? $name }}" class="form-label">{!! $label !!}</label>
        @endisset
        <div class="relative">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <select {{ $attributes->except('class') }} id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-input @isset($icon) pl-10 @endisset">
                {{ $slot }}
            </select>
        </div>
        @error($name)
            <label for="{{ $id ?? $name }}" class="text-sm text-danger-400 mt-1 block">{{ $message }}</label>
        @enderror
    </div>
@elseif($type == 'textarea')
    <div @isset($class) class="{{ $class }}" @endisset>
        @isset($label)
            <label for="{{ $id ?? $name }}" class="form-label">{!! $label !!}</label>
        @endisset
        <div class="relative">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <textarea {{ $attributes->except('class') }} id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-input @isset($icon) pl-10 @endisset" rows="4">{{ $value ?? $slot }}</textarea>
        </div>
        @error($name)
            <label for="{{ $id ?? $name }}" class="text-sm text-danger-400 mt-1 block">{{ $message }}</label>
        @enderror
    </div>
@elseif($type == 'file')
    <div @isset($class) class="{{ $class }}" @endisset>
        {{ $slot }}
        @isset($label)
            <label for="{{ $id ?? $name }}" class="form-label">{{ $label }}</label>
        @endisset
        <div class="relative">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <input type={{ $type }} {{ $attributes->except('class') }}
                @isset($value) value="{{ $value }}" @else value="{{ old($name) }}" @endisset
                id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-input @isset($icon) pl-10 @endisset disabled:opacity-50">
        </div>
        @error($name)
            <label for={{ $id ?? $name }} class="text-sm text-danger-400 mt-1 block">{{ $message }}</label>
        @enderror
    </div>
@else 
    <div @isset($class) class="{{ $class }}" @endisset>
        {{ $slot }}
        @isset($label)
            <label for="{{ $id ?? $name }}" class="form-label">{{ $label }}</label>
        @endisset
        <div class="relative">
            @isset($icon)
                <div class="absolute pointer-events-none top-0 left-0 py-2 px-4">
                    <i class="{{ $icon }}"></i>
                </div>
            @endisset
            <input type={{ $type }} {{ $attributes->except('class') }}
                @isset($value) value="{{ $value }}" @else value="{{ old($name) }}" @endisset
                id={{ $id ?? $name }}
                @isset($required) {{ $required ? 'required' : '' }} @endisset
                class="form-input @isset($icon) pl-10 @endisset">
        </div>
        @error($name)
            <label for={{ $id ?? $name }} class="text-sm text-danger-400 mt-1 block">{{ $message }}</label>
        @enderror
    </div>
@endif

