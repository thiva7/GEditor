@props(['paginator'])
@if ($paginator->hasPages())
    <nav role="navigation" aria-label="Pagination Navigation" {{ $attributes->merge(['class' => 'flex items-center justify-center gap-2']) }}>
        {{-- Previous Page Link --}}
        @if ($paginator->onFirstPage())
            <span class="px-3 py-2 text-sm font-medium text-secondary-400 bg-secondary-100 dark:bg-secondary-200 rounded-lg cursor-not-allowed"
                aria-disabled="true" aria-label="@lang('pagination.previous')">
                <span aria-hidden="true">@lang('pagination.previous')</span>
            </span>
        @else
            <a href="{{ $paginator->previousPageUrl() }}" rel="prev"
                class="px-3 py-2 text-sm font-medium text-secondary-700 dark:text-secondary-600 bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg hover:bg-secondary-50 dark:hover:bg-secondary-200 transition-colors duration-200">
                @lang('pagination.previous')
            </a>
        @endif

        {{-- Pagination Elements --}}
        <div class="flex items-center gap-1">
        @for ($i = 1; $i <= $paginator->lastPage(); $i++)
            {{-- "Three Dots" Separator --}}
            @if ($paginator->currentPage() > 3 && $i === 2)
                <span class="px-3 py-2 text-sm font-medium text-secondary-500">...</span>
            @endif

            {{-- Array Of Links --}}
            @if ($i == $paginator->currentPage())
                <span class="px-3 py-2 text-sm font-medium text-white bg-primary-400 rounded-lg">{{ $i }}</span>
            @elseif($i === $paginator->currentPage() + 1 || $i === $paginator->currentPage() + 2)
                <a href="{{ $paginator->url($i) }}"
                    class="px-3 py-2 text-sm font-medium text-secondary-700 dark:text-secondary-600 bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg hover:bg-secondary-50 dark:hover:bg-secondary-200 transition-colors duration-200">{{ $i }}</a>
            @elseif($i === $paginator->currentPage() - 1 || $i === $paginator->currentPage() - 2)
                <a href="{{ $paginator->url($i) }}"
                    class="px-3 py-2 text-sm font-medium text-secondary-700 dark:text-secondary-600 bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg hover:bg-secondary-50 dark:hover:bg-secondary-200 transition-colors duration-200">{{ $i }}</a>
            @endif

            {{-- "Three Dots" Separator --}}
            @if ($paginator->currentPage() < $paginator->lastPage() - 2 && $i === $paginator->lastPage() - 1)
                <span class="px-3 py-2 text-sm font-medium text-secondary-500">...</span>
            @endif
        @endfor
        </div>
        {{-- Next Page Link --}}
        @if ($paginator->hasMorePages())
            <a href="{{ $paginator->nextPageUrl() }}" rel="next"
                class="px-3 py-2 text-sm font-medium text-secondary-700 dark:text-secondary-600 bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg hover:bg-secondary-50 dark:hover:bg-secondary-200 transition-colors duration-200">
                @lang('pagination.next')
            </a>
        @else
            <span class="px-3 py-2 text-sm font-medium text-secondary-400 bg-secondary-100 dark:bg-secondary-200 rounded-lg cursor-not-allowed"
                aria-disabled="true" aria-label="@lang('pagination.next')">
                <span aria-hidden="true">@lang('pagination.next')</span>
            </span>
        @endif
    </nav>
@endif

