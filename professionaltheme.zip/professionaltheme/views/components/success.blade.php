@if (session('success'))
    <div id="success" class="fixed bottom-4 right-4 z-50 flex items-center p-4 mb-4 text-sm text-success-800 bg-success-50 dark:bg-success-900/30 dark:text-success-400 rounded-lg shadow-lg border border-success-200 dark:border-success-800" role="alert">
        <svg class="flex-shrink-0 w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
        </svg>
        <span class="sr-only">Info</span>
        <div class="ml-3 text-sm font-medium">
            {{ session('success') }}
        </div>
        <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-success-50 text-success-500 rounded-lg focus:ring-2 focus:ring-success-400 p-1.5 hover:bg-success-100 dark:bg-success-900/30 dark:text-success-400 dark:hover:bg-success-900/50 inline-flex items-center justify-center h-8 w-8 transition-colors duration-200" data-dismiss-target="#success" aria-label="Close">
            <span class="sr-only">Close</span>
            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
            </svg>
        </button>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const alertElement = document.getElementById('success');
            setTimeout(function() {
                if (alertElement) {
                    alertElement.style.transition = 'opacity 0.5s ease-in-out';
                    alertElement.style.opacity = '0';
                    setTimeout(function() {
                        alertElement.remove();
                    }, 500);
                }
            }, 5000);
        });
    </script>
@endif
@if(session('error'))
    <div id="error" class="fixed bottom-4 right-4 z-50 flex items-center p-4 mb-4 text-sm text-danger-800 bg-danger-50 dark:bg-danger-900/30 dark:text-danger-400 rounded-lg shadow-lg border border-danger-200 dark:border-danger-800" role="alert">
        <svg class="flex-shrink-0 w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
        </svg>
        <span class="sr-only">Info</span>
        <div class="ml-3 text-sm font-medium">
            {{ session('error') }}
        </div>
        <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-danger-50 text-danger-500 rounded-lg focus:ring-2 focus:ring-danger-400 p-1.5 hover:bg-danger-100 dark:bg-danger-900/30 dark:text-danger-400 dark:hover:bg-danger-900/50 inline-flex items-center justify-center h-8 w-8 transition-colors duration-200" data-dismiss-target="#error" aria-label="Close">
            <span class="sr-only">Close</span>
            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
            </svg>
        </button>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const alertElement = document.getElementById('error');
            setTimeout(function() {
                if (alertElement) {
                    alertElement.style.transition = 'opacity 0.5s ease-in-out';
                    alertElement.style.opacity = '0';
                    setTimeout(function() {
                        alertElement.remove();
                    }, 500);
                }
            }, 5000);
        });
    </script>
@endif
@props(['errors'])

@if ($errors->any())
    <div id="errors" class="fixed bottom-4 right-4 z-50 flex items-start p-4 mb-4 text-sm text-danger-800 bg-danger-50 dark:bg-danger-900/30 dark:text-danger-400 rounded-lg shadow-lg border border-danger-200 dark:border-danger-800 max-w-md" role="alert">
        <svg class="flex-shrink-0 w-5 h-5 mt-0.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
        </svg>
        <div class="ml-3 flex-1">
            <div class="font-medium mb-1">Something went wrong:</div>
            <ul class="list-disc list-inside space-y-1">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-danger-50 text-danger-500 rounded-lg focus:ring-2 focus:ring-danger-400 p-1.5 hover:bg-danger-100 dark:bg-danger-900/30 dark:text-danger-400 dark:hover:bg-danger-900/50 inline-flex items-center justify-center h-8 w-8 transition-colors duration-200" data-dismiss-target="#errors" aria-label="Close">
            <span class="sr-only">Close</span>
            <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
            </svg>
        </button>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const alertElement = document.getElementById('errors');
            setTimeout(function() {
                if (alertElement) {
                    alertElement.style.transition = 'opacity 0.5s ease-in-out';
                    alertElement.style.opacity = '0';
                    setTimeout(function() {
                        alertElement.remove();
                    }, 500);
                }
            }, 8000);
        });
    </script>
@endif

