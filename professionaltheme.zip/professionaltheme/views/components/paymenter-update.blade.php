@if(Auth::check() && Auth::user()->has('ADMINISTRATOR'))
    @if(config('app.commit') && config('app.version') === 'beta' && config('app.commit') !== config('settings::latest_version'))
        <div id="modal_update" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
            <div class="relative w-full max-w-xl max-h-full">
                <div class="relative bg-white dark:bg-secondary-100 rounded-xl shadow-lg border border-secondary-200 dark:border-secondary-200">
                    <button type="button" class="absolute top-3 right-2.5 text-secondary-400 bg-transparent hover:bg-secondary-100 dark:hover:bg-secondary-200 hover:text-secondary-600 dark:hover:text-secondary-300 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center transition-colors duration-200" data-modal-hide="modal_update">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                    <div class="p-6 text-center">
                        <i class="ri-error-warning-line text-6xl mb-4 text-warning-400"></i>
                        <h3 class="mb-5 text-lg font-semibold text-secondary-900 dark:text-secondary-900">{{ __('To download the beta version of Paymenter run:') }}</h3>
                        <blockquote class="p-4 my-4 border-l-4 border-primary-400 bg-primary-50 dark:bg-primary-900/20 relative rounded-r-lg">
                            <p class="text-sm font-mono leading-relaxed text-secondary-900 dark:text-secondary-900 copy_command">php artisan p:upgrade --url https://api.paymenter.org/beta</p>
                            <button id="copyButton" class="absolute top-2 right-2 bg-primary-400 text-white p-2 rounded-lg hover:bg-primary-300 transition-colors duration-200">
                                <i class="ri-file-copy-line"></i>
                            </button>
                        </blockquote>
                        <h3 class="mb-5 text-lg font-semibold text-secondary-900 dark:text-secondary-900">{{ __('in the paymenter directory') }}</h3>
                        <span class="text-sm text-secondary-500 dark:text-secondary-400">{{ __('THIS IS A BETA VERSION AND MAY CONTAIN BUGS. USE AT YOUR OWN RISK.') }}</span>
                    </div>
                </div>
            </div>
        </div>
        <script>
            document.getElementById('copyButton').addEventListener('click', function() {
                const textToCopy = document.querySelector('.copy_command').textContent;
                const textArea = document.createElement('textarea');
                textArea.value = textToCopy;
                document.body.appendChild(textArea);
                textArea.select();
                textArea.setSelectionRange(0, 99999);
                document.execCommand('copy');
                document.body.removeChild(textArea);
                this.innerHTML = "<i class='ri-check-line'></i>";
                this.classList.add('bg-success-400');
                setTimeout(() => {
                    this.innerHTML = "<i class='ri-file-copy-line'></i>";
                    this.classList.remove('bg-success-400');
                }, 2000);
            });
        </script>
    @endif
    @if((config('app.version') == 'beta' && config('app.commit') !== config('settings::latest_version')) || (config('app.version') !== 'beta' && config('app.version') !== 'development' && config('app.version') !== config('settings::latest_version')))
        <div id="update_panel" class="fixed hidden items-center w-full max-w-xs right-5 bottom-5 z-50" role="alert">
            <div id="toast-interactive" class="w-full max-w-xs p-4 text-secondary-600 dark:text-secondary-400 bg-white dark:bg-secondary-100 rounded-xl shadow-lg border border-secondary-200 dark:border-secondary-200" role="alert">
                <div class="flex">
                    <div class="inline-flex items-center justify-center flex-shrink-0 w-10 h-10 text-white bg-primary-400 rounded-lg">
                        <i class="ri-refresh-line"></i>
                    </div>
                    <div class="ml-3 text-sm font-normal flex-1">
                        <span class="mb-1 text-sm font-semibold text-secondary-900 dark:text-secondary-900 flex items-center gap-x-1">
                            {{ __('Update available') }}
                            <span class="text-xs font-normal text-secondary-500 dark:text-secondary-400 truncate max-w-[90px]">
                                ({{ config('settings::latest_version') }})
                            </span>
                        </span>
                        <div class="mb-3 text-sm font-normal text-secondary-600 dark:text-secondary-500">
                            @if(config('app.commit') && config('app.version') === 'beta')
                                {{ __('A new paymenter beta version is available for download.') }}
                            @else
                                {{ __('A new paymenter stable version is available for download.') }}
                            @endif
                        </div>
                        <div class="grid grid-cols-2 gap-2">
                            <div>
                                <a
                                    @if(config('app.commit') && config('app.version') === 'beta')
                                        data-modal-target="modal_update"
                                        data-modal-toggle="modal_update"
                                    @else
                                        href="https://paymenter.org/docs/how-to-update"
                                        target="_blank"
                                    @endif
                                    class="cursor-pointer inline-flex justify-center w-full px-3 py-2 text-xs font-medium text-center text-white bg-primary-400 rounded-lg hover:bg-primary-300 focus:ring-4 focus:outline-none focus:ring-primary-200 transition-all duration-200"
                                >
                                    {{ __('Update') }}
                                </a>
                            </div>
                            <div>
                                <a id="close_update_panel" class="cursor-pointer inline-flex justify-center w-full px-3 py-2 text-xs font-medium text-center text-secondary-700 dark:text-secondary-600 bg-secondary-100 dark:bg-secondary-200 border border-secondary-200 dark:border-secondary-200 rounded-lg hover:bg-secondary-200 dark:hover:bg-secondary-300 transition-all duration-200">{{ __('Not Now') }}</a>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-white dark:bg-secondary-100 text-secondary-400 hover:text-secondary-600 dark:hover:text-secondary-300 rounded-lg focus:ring-2 focus:ring-secondary-300 p-1.5 hover:bg-secondary-100 dark:hover:bg-secondary-200 inline-flex h-8 w-8 items-center justify-center transition-colors duration-200" data-dismiss-target="#toast-interactive" aria-label="Close">
                        <span class="sr-only">Close</span>
                        <i class="ri-close-line"></i>
                    </button>
                </div>
            </div>
        </div>
    
        <script>
            let expirationDate = localStorage.getItem('update_panel_expiration');
            let currentTime = new Date();
        
            if (!expirationDate || new Date(expirationDate) < currentTime) {
                document.getElementById('update_panel').style.display = 'flex';
            
                document.querySelector('#close_update_panel').addEventListener('click', function() {
                    document.getElementById('update_panel').style.display = 'none';
                
                    let date = new Date(currentTime.getTime() + (72 * 60 * 60 * 1000));
                    localStorage.setItem('update_panel_expiration', date.toISOString());
                });
            }
        </script>
    @endif
@endif

