@php
    $cart = session('cart', []);
    $count = count($cart);
@endphp
<a href="{{ route('checkout') }}" class="relative inline-flex items-center p-2 text-sm font-medium text-secondary-700 dark:text-secondary-600 hover:text-primary-400 transition-colors duration-200">
    <i class="ri-shopping-cart-line text-xl"></i>
    @if($count > 0)
        <span class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-primary-400 rounded-full">
            {{ $count }}
        </span>
    @endif
</a>

