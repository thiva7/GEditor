<footer class="mt-auto py-6 px-4 border-t border-secondary-200 dark:border-secondary-200">
    <div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-secondary-500 dark:text-secondary-400">
        <div>
            <a href="https://paymenter.org" class="hover:text-primary-400 transition-colors duration-200">
                {{ config('app.name', 'Paymenter') }} &copy; {{ date('Y') }}
            </a>
        </div>
        <div class="flex items-center gap-x-4">
            <a href="https://paymenter.org" class="hover:text-primary-400 transition-colors duration-200 flex items-center gap-x-1">
                <i class="ri-star-fill text-yellow-400"></i> Powered by Paymenter
            </a>
        </div>
    </div>
</footer>

