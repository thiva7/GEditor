@props(['errors'])

@if ($errors->any())
    <div {{ $attributes->merge(['class' => 'bg-danger-50 dark:bg-danger-900/30 border border-danger-200 dark:border-danger-800 rounded-lg p-4']) }}>
        <div class="font-medium text-danger-800 dark:text-danger-400 mb-2">
            {{ __('Whoops! Something went wrong.') }}
        </div>

        <ul class="mt-2 text-sm text-danger-700 dark:text-danger-400 list-disc list-inside space-y-1">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

