<x-app-layout clients>
    <div class="content min-h-[50vh] flex items-center justify-center">
        <div class="content-box max-w-md w-full">
            <div class="mb-4 text-sm text-secondary-600 dark:text-secondary-500">
                {{ __('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.') }}
            </div>

            @if (session('status') == 'verification-link-sent')
                <div class="mb-4 text-sm font-medium text-success-600 dark:text-success-400 bg-success-50 dark:bg-success-900/30 p-3 rounded-lg">
                    {{ __('A new verification link has been sent to the email address you provided during registration.') }}
                </div>
            @endif

            <div class="flex items-center justify-between mt-6">
                <form method="POST" action="{{ route('verification.send') }}">
                    @csrf
                    <button type="submit" class="button button-primary">
                        {{ __('Resend Verification Email') }}
                    </button>
                </form>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="text-sm text-secondary-600 dark:text-secondary-500 hover:text-primary-400 transition-colors duration-200">
                        {{ __('Log Out') }}
                    </button>
                </form>
            </div>
        </div>
    </div>
</x-app-layout>

