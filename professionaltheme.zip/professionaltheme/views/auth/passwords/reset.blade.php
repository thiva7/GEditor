<x-guest-layout>
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div class="text-center">
                <div class="flex items-center justify-center gap-x-3 mb-4">
                    <x-application-logo class="w-12" />
                    <span class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ config('app.name', 'Paymenter') }}</span>
                </div>
                <h2 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900">{{ __('Reset Password') }}</h2>
            </div>

            <div class="content-box">
                <x-auth-session-status class="mb-4" :status="session('status')" />
                <x-auth-validation-errors class="mb-4" :errors="$errors" />

                <form method="POST" action="{{ route('password.update') }}" id="reset-password" class="space-y-6">
                    @csrf
                    <input type="hidden" name="token" value="{{ $request->route('token') }}">

                    <x-input label="{{ __('Email') }}" type="email" name="email" id="email"
                        value="{{ old('email', $request->email) }}" required autocomplete="email" icon="ri-at-line" />

                    <x-input type="password" required label="{{ __('Password') }}"
                        name="password" id="password" autocomplete="new-password" icon="ri-lock-line"/>

                    <x-input type="password" required label="{{ __('Confirm Password') }}"
                        name="password_confirmation" id="password-confirm" autocomplete="new-password" icon="ri-lock-password-line"/>

                    <div class="flex items-center justify-center">
                        <x-recaptcha form="reset-password" />
                    </div>

                    <div class="flex items-center justify-end">
                        <button type="submit" class="button button-primary">
                            {{ __('Reset Password') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-guest-layout>

