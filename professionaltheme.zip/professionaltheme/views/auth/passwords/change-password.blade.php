<x-app-layout>
    <div class="content min-h-[50vh] flex items-center justify-center">
        <div class="content-box max-w-md w-full">
            <div class="text-center mb-6">
                <h2 class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ __('Reset Password') }}</h2>
            </div>
            
            <x-auth-session-status class="mb-4" :status="session('status')" />
            <x-auth-validation-errors class="mb-4" :errors="$errors" />

            <form method="POST" action="{{ route('change-password.update') }}" class="space-y-6">
                @csrf
                
                <x-input type="password" label="{{ __('Current Password') }}"
                    name="current_password" id="current_password" autocomplete="current_password" icon="ri-lock-line"/>

                <x-input type="password" label="{{ __('New Password') }}"
                    name="new_password" id="new_password" autocomplete="new_password" icon="ri-lock-line"/>

                <x-input type="password" label="{{ __('Confirm New Password') }}"
                    name="new_password_confirmation" id="new_password_confirmation" autocomplete="new_password_confirmation" icon="ri-lock-password-line"/>

                <div class="flex items-center justify-center">
                    <x-recaptcha />
                </div>

                <div class="flex items-center justify-end gap-x-3">
                    <a href="{{ url()->previous() == url()->current() ? url('/') : url()->previous() }}" class="button button-secondary">
                        {{ __('Cancel') }}
                    </a>
                    <button type="submit" class="button button-primary">
                        {{ __('Save Changes') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>

