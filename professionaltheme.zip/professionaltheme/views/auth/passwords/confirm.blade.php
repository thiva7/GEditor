<x-app-layout>
    <div class="content min-h-[50vh] flex items-center justify-center">
        <div class="content-box max-w-md w-full">
            <div class="mb-4 text-sm text-secondary-600 dark:text-secondary-500">
                {{ __('This is a secure area of the application. Please confirm your password before continuing.') }}
            </div>

            <form method="POST" action="{{ route('password.confirm') }}" id="pw-confirm" class="space-y-6">
                @csrf

                <x-input id="password" type="password" label="{{ __('Password') }}"
                    name="password" required autocomplete="current-password" icon="ri-lock-line"/>

                <div class="flex items-center justify-center">
                    <x-recaptcha form="pw-confirm" />
                </div>

                <div class="flex justify-end">
                    <button type="submit" class="button button-primary">
                        {{ __('Confirm') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>

