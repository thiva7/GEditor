<x-guest-layout>
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div class="text-center">
                <div class="flex items-center justify-center gap-x-3 mb-4">
                    <x-application-logo class="w-12" />
                    <span class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ config('app.name', 'Paymenter') }}</span>
                </div>
                <h2 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900">{{ __('Forgot Password') }}</h2>
                <p class="mt-2 text-sm text-secondary-600 dark:text-secondary-500">
                    {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}
                </p>
            </div>

            <div class="content-box">
                <form method="POST" action="{{ route('password.email') }}" id="forget-password" class="space-y-6">
                    @csrf
                    
                    <x-input label="{{ __('Email') }}" type="email" placeholder="{{ __('Email..') }}" required
                        name="email" id="email" icon="ri-at-line" />

                    <div class="flex items-center justify-center">
                        <x-recaptcha form="forget-password" />
                    </div>

                    <div class="flex justify-between items-center">
                        <a href="{{ route('login') }}" class="text-sm text-secondary-600 dark:text-secondary-500 hover:text-primary-400 transition-colors duration-200">
                            {{ __('Return to Login') }}
                        </a>
                        <button type="submit" class="button button-primary">
                            {{ __('Email Password Reset Link') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</x-guest-layout>

