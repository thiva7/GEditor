<x-app-layout>
    <div class="content min-h-[50vh] flex items-center justify-center">
        <div class="content-box max-w-md w-full">
            <div class="text-center mb-6">
                <div class="flex items-center justify-center gap-x-3 mb-4">
                    <x-application-logo class="w-12" />
                    <span class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ config('app.name', 'Paymenter') }}</span>
                </div>
                <h2 class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ __('Two Factor Authentication') }}</h2>
                <p class="mt-2 text-sm text-secondary-600 dark:text-secondary-500">
                    {{ __('Please enter the code from your authenticator app.') }}
                </p>
            </div>

            <form method="POST" action="{{ route('tfa') }}" id="tfa" class="space-y-6">
                @csrf
                
                <x-input id="code" type="text" label="{{ __('Code') }}" name="code" required icon="ri-shield-check-line" />

                <div class="flex items-center justify-center">
                    <x-recaptcha form="tfa" />
                </div>

                <div class="flex items-center justify-end">
                    <button type="submit" class="button button-primary">
                        {{ __('Submit') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>

