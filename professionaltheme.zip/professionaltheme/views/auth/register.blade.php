<x-guest-layout>
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-2xl w-full space-y-8">
            @if (config('settings::registrationAbillity_disable') == 1)
                <div class="content-box bg-danger-50 dark:bg-danger-900/30 border-danger-200 dark:border-danger-800 text-center py-6">
                    <h1 class="font-bold text-danger-800 dark:text-danger-400">{{ __('REGISTRATION IS CURRENTLY DISABLED') }}</h1>
                </div>
            @else
                <div class="text-center">
                    <div class="flex items-center justify-center gap-x-3 mb-4">
                        <x-application-logo class="w-12" />
                        <span class="text-2xl font-bold text-secondary-900 dark:text-secondary-900">{{ config('app.name', 'Paymenter') }}</span>
                    </div>
                    <h2 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900">{{ __('Create your account') }}</h2>
                    <p class="mt-2 text-sm text-secondary-600 dark:text-secondary-500">
                        {{ __('Already have an account?') }}
                        <a href="{{ route('login') }}" class="font-medium text-primary-400 hover:text-primary-300">
                            {{ __('Sign in') }}
                        </a>
                    </p>
                </div>

                <div class="content-box">
                    <form method="POST" action="{{ route('register') }}" id="register" class="space-y-6">
                        @csrf

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <x-input label="{{ __('First name') }}" type="text" placeholder="{{ __('First name..') }}" required
                                name="first_name" id="first_name" icon="ri-user-3-line" />

                            <x-input label="{{ __('Last name') }}" type="text" placeholder="{{ __('Last name..') }}" required
                                name="last_name" id="last_name" icon="ri-user-3-line" />
                        </div>

                        <x-input label="{{ __('Email') }}" type="email" placeholder="{{ __('Email..') }}" required
                            name="email" id="email" icon="ri-at-line" />

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            @if(config('settings::requiredClientDetails_address') == 1)
                                <x-input label="{{ __('Address') }}" type="text" placeholder="{{ __('Address..') }}"
                                    name="address" id="address" icon="ri-home-4-line" />
                            @endif
                            @if(config('settings::requiredClientDetails_city') == 1)
                                <x-input label="{{ __('City') }}" type="text" placeholder="{{ __('City..') }}" required
                                    name="city" id="city" icon="ri-building-2-line" />
                            @endif
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            @if(config('settings::requiredClientDetails_phone') == 1)
                                <x-input label="{{ __('Phone') }}" type="text" placeholder="{{ __('Phone..') }}" required
                                    name="phone" id="phone" icon="ri-phone-line" />
                            @endif
                            @if(config('settings::requiredClientDetails_zip') == 1)
                                <x-input label="{{ __('Zip') }}" type="text" placeholder="{{ __('Zip..') }}" required
                                    name="zip" id="zip" icon="ri-building-2-line" />
                            @endif
                        </div>

                        @if(config('settings::requiredClientDetails_country') == 1)
                            <x-input type="select" placeholder="{{ __('Country') }}" name="country"
                                id="country" label="{{ __('Country') }}" required="required">
                                @foreach (App\Classes\Constants::countries() as $key => $country)
                                    <option value="{{ $key }}">
                                        {{ $country }}
                                    </option>
                                @endforeach
                            </x-input>
                        @endif

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <x-input type="password" required label="{{ __('Password') }}"
                                placeholder="{{ __('Password..') }}" name="password" id="password" icon="ri-lock-line"/>

                            <x-input type="password" required label="{{ __('Confirm Password') }}"
                                placeholder="{{ __('Password..') }}" name="password_confirmation" id="password-confirm" icon="ri-lock-password-line"/>
                        </div>

                        <div class="flex items-center justify-center">
                            <x-recaptcha form="register" />
                        </div>

                        <div class="flex justify-between items-center">
                            <a href="{{ route('login') }}" class="text-sm text-secondary-600 dark:text-secondary-500 hover:text-primary-400 transition-colors duration-200">
                                {{ __('Already registered?') }}
                            </a>
                            <button type="submit" class="button button-primary">
                                {{ __('Register') }}
                            </button>
                        </div>
                    </form>
                </div>
            @endif
        </div>
    </div>
</x-guest-layout>

