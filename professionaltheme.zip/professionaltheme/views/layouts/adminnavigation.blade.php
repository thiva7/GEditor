<nav class="bg-white dark:bg-secondary-100 border-b border-secondary-200 dark:border-secondary-200 shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <div class="flex items-center gap-x-4">
                <a href="{{ route('index') }}" class="flex items-center gap-x-3">
                    <x-application-logo class="w-10" />
                    <span class="text-lg font-semibold text-secondary-900 dark:text-secondary-900">{{ config('app.name', 'Paymenter') }}</span>
                </a>
            </div>

            <!-- Desktop Navigation -->
            <div class="hidden lg:flex items-center gap-x-1">
                <a href="{{ route('admin.index') }}" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.index')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-dashboard-line mr-1"></i> {{ __('Dashboard') }}
                </a>
                
                <div class="relative">
                    <button type="button" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 flex items-center gap-x-1 @if (request()->routeIs('admin.clients*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif" data-dropdown-toggle="clients">
                        <i class="ri-group-line"></i> {{ __('Clients') }}
                        <i class="ri-arrow-down-s-line text-xs"></i>
                    </button>
                    <div class="absolute left-0 hidden w-56 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10" id="clients">
                        <div class="py-1">
                            <a href="{{ route('admin.clients') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{__('All Clients')}}</a>
                            <a href="{{ route('admin.clients.create') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{__('Create Client')}}</a>
                        </div>
                    </div>
                </div>

                <a href="{{ route('admin.orders') }}" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.orders*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-shopping-cart-2-line mr-1"></i> {{__('Orders')}}
                </a>

                <a href="{{ route('admin.invoices') }}" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.invoices*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-bill-line mr-1"></i> {{__('Invoices')}}
                </a>

                <div class="relative">
                    <button type="button" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 flex items-center gap-x-1 @if (request()->routeIs('admin.products*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif" data-dropdown-toggle="products">
                        <i class="ri-shopping-bag-2-line"></i> {{ __('Products') }}
                        <i class="ri-arrow-down-s-line text-xs"></i>
                    </button>
                    <div class="absolute left-0 hidden w-56 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10" id="products">
                        <div class="py-1">
                            <a href="{{ route('admin.products') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('All Products') }}</a>
                            <a href="{{ route('admin.products.create') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Create Product') }}</a>
                            <hr class="my-1 border-secondary-200 dark:border-secondary-200">
                            <a href="{{ route('admin.categories') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Categories') }}</a>
                        </div>
                    </div>
                </div>

                <div class="relative">
                    @php $unread = App\Models\Ticket::where('status', 'open')->count(); @endphp
                    <button type="button" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 flex items-center gap-x-1 @if (request()->routeIs('admin.tickets*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif" data-dropdown-toggle="support">
                        <i class="ri-question-answer-line"></i> {{ __('Support') }}
                        @if ($unread > 0)
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-danger-100 text-danger-800 dark:bg-danger-900/30 dark:text-danger-400">
                                {{ $unread }}
                            </span>
                        @endif
                        <i class="ri-arrow-down-s-line text-xs"></i>
                    </button>
                    <div class="absolute left-0 hidden w-56 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10" id="support">
                        <div class="py-1">
                            <a href="{{ route('admin.tickets') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                {{ __('All Support') }}
                                @if ($unread > 0)
                                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-danger-100 text-danger-800 dark:bg-danger-900/30 dark:text-danger-400 ml-2">
                                        {{ $unread }}
                                    </span>
                                @endif
                            </a>
                            <a href="{{ route('admin.tickets.create') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Create Ticket') }}</a>
                        </div>
                    </div>
                </div>

                <div class="relative">
                    <button type="button" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.settings') || request()->routeIs('admin.extensions*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif" data-dropdown-toggle="other">
                        <i class="ri-more-2-line"></i>
                    </button>
                    <div class="absolute right-0 hidden w-max mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10" id="other">
                        <div class="py-1 grid grid-cols-3 gap-1">
                            <a href="{{ route('admin.settings') }}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Settings') }}</a>
                            <a href="{{ route('admin.extensions') }}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Extensions') }}</a>
                            <a href="{{ route('admin.coupons') }}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Coupons') }}</a>
                            <a href="{{ route('admin.announcements')}}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Announcements') }}</a>
                            <a href="{{ route('admin.roles') }}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Roles') }}</a>
                            <a href="{{ route('admin.taxes') }}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Taxes') }}</a>
                            <a href="{{ route('admin.logs') }}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">{{ __('Logs') }}</a>
                            <a href="{{ route('admin.configurable-options')}}" class="px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200 col-span-3">{{ __('Configurable Options') }}</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- User Menu -->
            <div class="flex items-center gap-x-3">
                <div class="relative">
                    <button type="button" class="flex items-center gap-x-2" data-dropdown-toggle="user-menu">
                        <img class="w-8 h-8 rounded-lg" src="https://www.gravatar.com/avatar/{{ md5(Auth::user()->email) }}?s=200&d=mp" alt="{{ Auth::user()->name }}" />
                        <span class="hidden md:block font-medium text-secondary-700 dark:text-secondary-600">{{ Auth::user()->name }}</span>
                    </button>
                    <div class="absolute right-0 hidden w-56 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10" id="user-menu">
                        <div class="py-1">
                            <a href="{{ route('clients.profile') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                <i class="ri-user-line mr-2"></i> {{ __('Your Profile') }}
                            </a>
                            <a href="{{ route('admin.settings') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                <i class="ri-settings-3-line mr-2"></i> {{ __('Settings') }}
                            </a>
                            <a href="{{ route('clients.password.change-password') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                <i class="ri-key-2-line mr-2"></i> {{ __('Change Password') }}
                            </a>
                            <a href="{{ route('clients.home') }}" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                <i class="ri-dashboard-line mr-2"></i> {{ __('User Dashboard') }}
                            </a>
                            <hr class="my-1 border-secondary-200 dark:border-secondary-200">
                            <a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="block px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                <i class="ri-logout-box-line mr-2"></i> {{ __('Sign out') }}
                            </a>
                        </div>
                    </div>
                </div>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                    @csrf
                </form>
            </div>

            <!-- Mobile menu button -->
            <div class="lg:hidden">
                <button type="button" class="button button-secondary-outline !p-2" onclick="document.getElementById('mobile-menu').classList.toggle('hidden')" aria-label="Toggle menu">
                    <i class="ri-menu-line"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile menu -->
    <div class="lg:hidden hidden border-t border-secondary-200 dark:border-secondary-200" id="mobile-menu">
        <div class="px-4 py-4 space-y-1">
            <a href="{{ route('admin.index') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.index')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-dashboard-line mr-2"></i> {{ __('Dashboard') }}
            </a>
            <a href="{{ route('admin.clients') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.clients*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-group-line mr-2"></i> {{ __('Clients') }}
            </a>
            <a href="{{ route('admin.orders') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.orders*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-shopping-cart-2-line mr-2"></i> {{ __('Orders') }}
            </a>
            <a href="{{ route('admin.invoices') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.invoices*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-bill-line mr-2"></i> {{ __('Invoices') }}
            </a>
            <a href="{{ route('admin.products') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.products*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-shopping-bag-2-line mr-2"></i> {{ __('Products') }}
            </a>
            <a href="{{ route('admin.tickets') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.tickets*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-question-answer-line mr-2"></i> {{ __('Support') }}
            </a>
            <a href="{{ route('admin.settings') }}" class="block px-3 py-2 text-base font-medium rounded-lg @if (request()->routeIs('admin.settings*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                <i class="ri-settings-3-line mr-2"></i> {{ __('Settings') }}
            </a>
        </div>
    </div>
</nav>

