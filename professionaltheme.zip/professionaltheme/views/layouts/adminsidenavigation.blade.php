<div class="hidden 2xl:flex shrink-0 w-64">
    <aside class="fixed top-0 bottom-0 left-0 w-64 bg-white dark:bg-secondary-100 border-r border-secondary-200 dark:border-secondary-200 overflow-y-auto">
        <div class="p-4">
            <a href="{{ route('index') }}" class="flex items-center gap-x-3 mb-6">
                <x-application-logo class="w-10" />
                <span class="text-lg font-semibold text-secondary-900 dark:text-secondary-900">{{ config('app.name', 'Paymenter') }}</span>
            </a>

            <div class="mb-4">
                <div class="flex items-center gap-x-3 px-3 py-2 rounded-lg hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200 cursor-pointer" onclick="toggleProfileMenu()">
                    <img class="w-8 h-8 rounded-lg" src="https://www.gravatar.com/avatar/{{ md5(Auth::user()->email) }}?s=200&d=mp" alt="{{ Auth::user()->name }}" />
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-secondary-900 dark:text-secondary-900 truncate">{{ Auth::user()->name }}</p>
                        <p class="text-xs text-secondary-500 dark:text-secondary-400 truncate">{{ Auth::user()->email }}</p>
                    </div>
                    <i class="ri-arrow-down-s-line text-secondary-400" id="profile-arrow"></i>
                </div>
                <div class="hidden mt-2 ml-4 space-y-1" id="profile-menu">
                    <a href="{{ route('clients.profile') }}" class="block px-3 py-2 text-sm text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded-lg transition-colors duration-200">
                        <i class="ri-user-line mr-2"></i> Profile Settings
                    </a>
                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="block px-3 py-2 text-sm text-danger-400 hover:bg-danger-50 dark:hover:bg-danger-900/20 rounded-lg transition-colors duration-200">
                        <i class="ri-logout-box-line mr-2"></i> Sign Out
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                        @csrf
                    </form>
                </div>
            </div>

            <hr class="my-4 border-secondary-200 dark:border-secondary-200">

            <nav class="space-y-1">
                <a href="{{ route('admin.settings') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.settings')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-settings-2-line"></i> Paymenter Settings
                </a>

                <div class="px-3 py-2 text-sm font-medium text-secondary-500 dark:text-secondary-400 uppercase tracking-wider">Support</div>
                <div class="flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg cursor-pointer hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200 @if (request()->routeIs('admin.tickets*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 @endif" onclick="toggleTicketsMenu()">
                    <div class="flex items-center gap-x-3">
                        <i class="ri-coupon-line"></i> Tickets
                    </div>
                    <i class="ri-arrow-down-s-line text-xs" id="tickets-arrow"></i>
                </div>
                <div class="hidden ml-4 space-y-1" id="tickets-menu">
                    <a href="{{ route('admin.tickets.create') }}" class="block px-3 py-2 text-sm text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded-lg transition-colors duration-200">
                        Create Ticket
                    </a>
                    <a href="{{ route('admin.tickets') }}" class="block px-3 py-2 text-sm text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded-lg transition-colors duration-200">
                        View Tickets
                    </a>
                </div>

                <div class="px-3 py-2 text-sm font-medium text-secondary-500 dark:text-secondary-400 uppercase tracking-wider mt-4">Products</div>
                <a href="{{ route('admin.products') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.products')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-shopping-basket-2-fill"></i> Products
                </a>
                <a href="{{ route('admin.categories') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.categories')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-folders-line"></i> Categories
                </a>

                <div class="px-3 py-2 text-sm font-medium text-secondary-500 dark:text-secondary-400 uppercase tracking-wider mt-4">Orders & Clients</div>
                <a href="{{ route('admin.orders') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.orders')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-file-text-line"></i> Orders
                </a>
                <a href="{{ route('admin.clients') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 @if (request()->routeIs('admin.clients')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif">
                    <i class="ri-user-3-line"></i> Clients
                </a>
            </nav>
        </div>
    </aside>
    <script>
        function toggleProfileMenu() {
            const menu = document.getElementById('profile-menu');
            const arrow = document.getElementById('profile-arrow');
            menu.classList.toggle('hidden');
            arrow.classList.toggle('rotate-180');
        }

        function toggleTicketsMenu() {
            const menu = document.getElementById('tickets-menu');
            const arrow = document.getElementById('tickets-arrow');
            menu.classList.toggle('hidden');
            arrow.classList.toggle('rotate-180');
        }
    </script>
</div>

