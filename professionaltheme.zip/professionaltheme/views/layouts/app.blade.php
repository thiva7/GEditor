<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<!-- Software build by https://paymenter.org -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <script>
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
        window.addEventListener('keydown', function(e) {
            var ctrlDown = true;
            var ctrlKey = 17,
                enterKey = 13;
            $(document).keydown(function(e) {
                if (e.keyCode == ctrlKey) ctrlDown = true;
                if (e.keyCode == enterKey && ctrlDown) {
                    if ($('#submit').length) {
                        $('#submit').click();
                    }
                }
            }).keyup(function(e) {
                if (e.keyCode == ctrlKey) ctrlDown = false;
            });
        });
    </script>
    <style>
        :root {
            --secondary-50: {{ config('settings::theme:secondary-50', '#ffffff') }};
            --secondary-100: {{ config('settings::theme:secondary-100', '#f9fafb') }};
            --secondary-200: {{ config('settings::theme:secondary-200', '#f3f4f6') }};
            --secondary-300: {{ config('settings::theme:secondary-300', '#e5e7eb') }};
            --secondary-400: {{ config('settings::theme:secondary-400', '#9ca3af') }};
            --secondary-500: {{ config('settings::theme:secondary-500', '#6b7280') }};
            --secondary-600: {{ config('settings::theme:secondary-600', '#4b5563') }};
            --secondary-700: {{ config('settings::theme:secondary-700', '#374151') }};
            --secondary-800: {{ config('settings::theme:secondary-800', '#1f2937') }};
            --secondary-900: {{ config('settings::theme:secondary-900', '#111827') }};

            --primary-50: {{ config('settings::theme:primary-50', '#eff6ff') }};
            --primary-100: {{ config('settings::theme:primary-100', '#dbeafe') }};
            --primary-200: {{ config('settings::theme:primary-200', '#bfdbfe') }};
            --primary-300: {{ config('settings::theme:primary-300', '#93c5fd') }};
            --primary-400: {{ config('settings::theme:primary-400', '#3b82f6') }};
        }

        .dark {
            --secondary-50: {{ config('settings::theme:secondary-50-dark', '#0f172a') }};
            --secondary-100: {{ config('settings::theme:secondary-100-dark', '#1e293b') }};
            --secondary-200: {{ config('settings::theme:secondary-200-dark', '#334155') }};
            --secondary-300: {{ config('settings::theme:secondary-300-dark', '#475569') }};
            --secondary-400: {{ config('settings::theme:secondary-400-dark', '#64748b') }};
            --secondary-500: {{ config('settings::theme:secondary-500-dark', '#94a3b8') }};
            --secondary-600: {{ config('settings::theme:secondary-600-dark', '#cbd5e1') }};
            --secondary-700: {{ config('settings::theme:secondary-700-dark', '#e2e8f0') }};
            --secondary-800: {{ config('settings::theme:secondary-800-dark', '#f1f5f9') }};
            --secondary-900: {{ config('settings::theme:secondary-900-dark', '#ffffff') }};
        }
    </style>
    @empty($title)
        <title>{{ config('app.name', 'Paymenter') }}</title>
    @else
        <title>{{ config('app.name', 'Paymenter') . ' - ' . ucfirst($title) }}</title>
    @endempty

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">

    @vite(['themes/' . config('settings::theme-active') . '/js/app.js', 'themes/' . config('settings::theme-active') . '/css/app.css'], config('settings::theme-active'))

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">
    @if (config('settings::app_logo'))
        <link rel="icon" href="{{ asset(config('settings::app_logo')) }}" type="image/png">
    @else
        <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon-16x16.png">
    @endif
    <meta content="{{ ucfirst($title) ?? config('settings::seo_title') }}" property="og:title">
    <meta content="{{ $description ?? config('settings::seo_description') }}" property="og:description">
    <meta content="{{ $description ?? config('settings::seo_description') }}" name="description">
    <meta content='{{ $image ?? config('settings::seo_image') }}' property='og:image'>
    <link type="application/json+oembed"
        href="{{ url('/') }}/manifest.json?title={{ config('app.name', 'Paymenter') }}&author_url={{ url('/') }}&author_name={{ config('app.name', 'Paymenter') }}" />
    <meta name="twitter:card" content="@if (config('settings::seo_twitter_card')) summary_large_image @endif">
    <meta name="theme-color" content="#3B82F6">
</head>

<body class="font-sans bg-secondary-100 dark:bg-secondary-50 text-secondary-700 dark:text-secondary-800 antialiased">

    <div id="app" class="min-h-screen">
        <x-paymenter-update />
        @if (!$clients || config('settings::sidebar') == 0)
            @include('layouts.navigation')
        @endif
        <div class="@if (config('settings::sidebar') == 1) flex md:flex-nowrap flex-wrap @endif">
            @if ($clients)
                @include('layouts.subnavigation')
            @endif
            <div class="w-full flex flex-col @if ($clients) min-h-[calc(100vh-105px)] @else min-h-[calc(100vh-64px)] @endif">
                
                <main class="grow">
                    {{ $slot }}
                </main>

                <x-footer />
            </div>
        </div>
    </div>
</body>

</html>

