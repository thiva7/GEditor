<nav class="bg-white dark:bg-secondary-100 border-b border-secondary-200 dark:border-secondary-200 shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
            <div class="flex items-center">
                <a href="{{ route('index') }}" class="flex items-center gap-x-3 text-secondary-900 dark:text-secondary-900 font-semibold text-lg">
                    <x-application-logo class="w-10" />
                    {{ config('app.name', 'Paymenter') }}
                </a>
            </div>
            
            <!-- Desktop Navigation -->
            <div class="hidden md:flex items-center gap-x-6">
                <a href="{{ route('index') }}" class="text-secondary-700 dark:text-secondary-600 hover:text-primary-400 dark:hover:text-primary-400 transition-colors duration-200">
                    {{ __('Home') }}
                </a>
                @auth
                    <a href="{{ route('clients.home') }}" class="text-secondary-700 dark:text-secondary-600 hover:text-primary-400 dark:hover:text-primary-400 transition-colors duration-200">
                        {{ __('Customer Area') }}
                    </a>
                @endauth
                <button type="button" aria-expanded="true" data-dropdown-placement="bottom-start" aria-haspopup="true"
                    data-dropdown-toggle="orders"
                    class="text-secondary-700 dark:text-secondary-600 hover:text-primary-400 dark:hover:text-primary-400 transition-colors duration-200 flex items-center gap-x-1">
                    {{ __('Shop') }} <i class="ri-arrow-down-s-line"></i>

                    <div class="absolute left-0 hidden w-56 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10"
                        role="menu" aria-orientation="vertical" aria-labelledby="product" tabindex="-1" id="orders">
                        @foreach (App\Models\Category::whereNull('category_id')->orderBy('order')->get() as $category)
                            @if ($category->products()->where('hidden', false)->count() > 0 || $category->children->count() > 0)
                                <a href="{{ route('products', $category->slug) }}"
                                    class="flex px-4 py-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded transition-colors duration-200"
                                    role="menuitem" tabindex="-1">{{ $category->name }}</a>
                            @endif
                        @endforeach
                    </div>
                </button>
                <a href="{{ route('announcements.index') }}"
                    class="text-secondary-700 dark:text-secondary-600 hover:text-primary-400 dark:hover:text-primary-400 transition-colors duration-200">
                    {{ __('Announcements') }}
                </a>
            </div>

            <!-- Right side actions -->
            <div class="flex items-center gap-x-3">
                <livewire:cart-count />
                
                @auth
                    @if(Auth::user()->credits > 0 && config('settings::credits'))
                        <div class="hidden md:flex items-center">
                            <a href="{{ route('clients.credits') }}" class="text-sm text-secondary-600 dark:text-secondary-500 flex items-center gap-x-1">
                                <i class="ri-wallet-3-line"></i>
                                <span class="font-medium">
                                    <x-money :amount="Auth::user()->credits" />
                                </span>
                            </a>
                        </div>
                    @endif
                    <button type="button" aria-expanded="true" aria-haspopup="true" data-dropdown-placement="bottom-end"
                            data-dropdown-toggle="account" class="flex items-center gap-x-2">
                        <img class="w-8 h-8 rounded-lg" src="https://www.gravatar.com/avatar/{{md5(Auth::user()->email)}}?s=200&d=mp" alt="Avatar"/>
                        <span class="hidden md:block font-medium text-secondary-700 dark:text-secondary-600">
                            {{ Auth::user()->first_name }}
                        </span>
                        <div class="absolute right-0 hidden w-60 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10"
                             role="menu" aria-orientation="vertical" tabindex="-1" id="account">
                            <div class="py-2">
                                <a href="{{ route('clients.profile') }}" class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                    <i class="ri-account-circle-line"></i> {{__('Profile')}}
                                </a>
                                @if (Auth::user()->has('ADMINISTRATOR'))
                                    <a href="{{ route('admin.index') }}" class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                        <i class="ri-key-2-line"></i> {{ __('Admin area') }}
                                    </a>
                                    <a href="{{ route('clients.api.index') }}" class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                        <i class="ri-code-s-slash-line"></i> {{ __('API') }}
                                    </a>
                                @endif
                                <hr class="my-1 border-secondary-200 dark:border-secondary-200" />
                                <a type="button" href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();"
                                   class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                    <i class="ri-logout-box-line"></i> {{ __('Log Out') }}
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                                    @csrf
                                </form>
                            </div>
                        </div>
                    </button>
                @else
                    <a href="{{ route('login') }}" class="button button-primary">
                        {{ __('Log In') }}
                    </a>
                @endauth
                <button class="button button-secondary-outline !p-2" id="theme-toggle" aria-label="Toggle theme">
                    <i class="ri-sun-line hidden dark:block"></i>
                    <i class="ri-moon-line dark:hidden"></i>
                </button>
                <script>
                    var themeToggleBtn = document.getElementById('theme-toggle');
                    themeToggleBtn.addEventListener('click', function() {
                        if (localStorage.getItem('theme')) {
                            if (localStorage.getItem('theme') === 'light') {
                                document.documentElement.classList.add('dark');
                                localStorage.setItem('theme', 'dark');
                            } else {
                                document.documentElement.classList.remove('dark');
                                localStorage.setItem('theme', 'light');
                            }
                        } else {
                            if (document.documentElement.classList.contains('dark')) {
                                document.documentElement.classList.remove('dark');
                                localStorage.setItem('theme', 'light');
                            } else {
                                document.documentElement.classList.add('dark');
                                localStorage.setItem('theme', 'dark');
                            }
                        }
                    });
                </script>
            </div>

            <!-- Mobile menu button -->
            <div class="md:hidden">
                <button type="button" class="button button-secondary-outline !p-2" onclick="openMobileMenu()" aria-label="Toggle menu">
                    <i class="ri-menu-line"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile menu -->
    <div class="md:hidden hidden" id="mobile-menu">
        <div class="px-4 pt-2 pb-4 space-y-1 border-t border-secondary-200 dark:border-secondary-200">
            <a href="{{ route('index') }}" class="block px-3 py-2 text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded-lg">
                {{ __('Home') }}
            </a>
            @auth
                <a href="{{ route('clients.home') }}" class="block px-3 py-2 text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded-lg">
                    {{ __('Customer Area') }}
                </a>
            @endauth
            <a href="{{ route('announcements.index') }}" class="block px-3 py-2 text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 rounded-lg">
                {{ __('Announcements') }}
            </a>
        </div>
    </div>
    <script>
        function openMobileMenu() {
            document.getElementById("mobile-menu").classList.toggle("hidden");
        }
    </script>
</nav>

