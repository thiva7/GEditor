@if (config('settings::sidebar') == 0)
    <div class="bg-white dark:bg-secondary-100 border-b border-secondary-200 dark:border-secondary-200 shadow-sm hidden md:block" id="clientsNavBar">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center gap-x-6">
                <a href="{{ route('clients.home') }}" class="py-3 flex items-center gap-x-2 text-sm font-medium @if (request()->routeIs('clients.home')) text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:text-primary-400 @endif transition-colors duration-200">
                    <i class="ri-layout-2-line"></i> {{ __('Dashboard') }}
                </a>
                <a href="{{ route('clients.invoice.index') }}" class="py-3 flex items-center gap-x-2 text-sm font-medium @if (request()->routeIs('clients.invoice*')) text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:text-primary-400 @endif transition-colors duration-200">
                    <i class="ri-file-paper-line"></i> {{ __('Invoices') }}
                </a>
                <a href="{{ route('clients.tickets.index') }}" class="py-3 flex items-center gap-x-2 text-sm font-medium @if (request()->routeIs('clients.tickets*')) text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:text-primary-400 @endif transition-colors duration-200">
                    <i class="ri-customer-service-2-line"></i> {{ __('Tickets') }}
                </a>
                <a href="{{ route('clients.profile') }}" class="py-3 flex items-center gap-x-2 text-sm font-medium @if (request()->routeIs('clients.profile')) text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:text-primary-400 @endif transition-colors duration-200">
                    <i class="ri-user-6-line"></i> {{ __('Profile Settings') }}
                </a>
            </div>
        </div>
    </div>
@else
    <div class="shrink-0 md:w-64 w-72 hidden sm:block md:sticky fixed top-0 h-screen z-40" id="clientsNavBar">
        <div class="bg-white dark:bg-secondary-100 border-r border-secondary-200 dark:border-secondary-200 h-full flex flex-col">
            <div class="px-4 py-4 border-b border-secondary-200 dark:border-secondary-200">
                <a href="{{ route('index') }}" class="flex items-center gap-x-3 text-secondary-900 dark:text-secondary-900 font-semibold text-lg">
                    <x-application-logo class="w-10" />
                    {{ config('app.name', 'Paymenter') }}
                </a>
            </div>
            <nav class="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
                <div class="text-xs font-semibold text-secondary-500 dark:text-secondary-400 uppercase tracking-wider mb-3">General</div>
                <a href="{{ route('index') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg @if (request()->routeIs('index')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                    <i class="ri-home-line"></i> {{ __('Home') }}
                </a>
                <a href="{{ route('announcements.index') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg @if (request()->routeIs('announcements.index')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                    <i class="ri-megaphone-line"></i> {{ __('Announcements') }}
                </a>
                <a href="{{ route('clients.tickets.index') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg @if (request()->routeIs('clients.tickets.index')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                    <i class="ri-customer-service-line"></i> {{ __('Help Center') }}
                </a>
                
                <div class="text-xs font-semibold text-secondary-500 dark:text-secondary-400 uppercase tracking-wider mb-3 mt-6">Dashboard</div>
                <a href="{{ route('clients.home') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg @if (request()->routeIs('clients.home')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                    <i class="ri-layout-2-line"></i> {{ __('Dashboard') }}
                </a>
                <a href="{{ route('clients.invoice.index') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg @if (request()->routeIs('clients.invoice*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                    <i class="ri-file-paper-line"></i> {{ __('Invoices') }}
                </a>
                <a href="{{ route('clients.tickets.index') }}" class="flex items-center gap-x-3 px-3 py-2 text-sm font-medium rounded-lg @if (request()->routeIs('clients.tickets*')) bg-primary-50 dark:bg-primary-900/20 text-primary-400 @else text-secondary-600 dark:text-secondary-500 hover:bg-secondary-100 dark:hover:bg-secondary-200 @endif transition-colors duration-200">
                    <i class="ri-customer-service-2-line"></i> {{ __('Tickets') }}
                </a>
            </nav>
            <div class="px-4 py-4 border-t border-secondary-200 dark:border-secondary-200">
                <div class="flex items-center gap-x-3">
                    <a href="{{ route('clients.profile') }}" class="flex items-center gap-x-3 flex-1 min-w-0">
                        <img class="w-8 h-8 rounded-lg"
                            src="https://www.gravatar.com/avatar/{{ md5(Auth::user()->email) }}?s=200&d=mp"
                            alt="{{ Auth::user()->name }}" />
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-secondary-900 dark:text-secondary-900 truncate">{{ Auth::user()->name }}</p>
                            <p class="text-xs text-secondary-500 dark:text-secondary-400 truncate">{{ Auth::user()->email }}</p>
                        </div>
                    </a>
                    <button type="button" aria-expanded="true" aria-haspopup="true" data-dropdown-placement="top"
                    data-dropdown-toggle="account" class="button button-secondary-outline !p-2">
                        <i class="ri-more-2-line"></i>
                        <div class="absolute left-0 hidden w-60 mt-2 origin-top-right bg-white dark:bg-secondary-100 border border-secondary-200 dark:border-secondary-200 rounded-lg shadow-lg z-10"
                        role="menu" aria-orientation="vertical" tabindex="-1" id="account">
                            <div class="py-2">
                                @if (Auth::user()->is_admin)
                                    <a href="{{ route('admin.index') }}"
                                        class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                        <i class="ri-key-2-line"></i> {{ __('Admin area') }}</a>
                                    <a href="{{ route('clients.api.index') }}"
                                        class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200">
                                        <i class="ri-code-s-slash-line"></i> {{ __('API') }}</a>
                                @endif
                                <hr class="my-1 border-secondary-200 dark:border-secondary-200" />
                                <a type="button" href="{{ route('logout') }}"
                                    class="px-4 py-2 flex items-center gap-x-2 text-sm text-secondary-700 dark:text-secondary-600 hover:bg-secondary-100 dark:hover:bg-secondary-200 transition-colors duration-200"
                                    onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                    <i class="ri-logout-box-line"></i> {{ __('Log Out') }}</a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                                    @csrf
                                </form>
                            </div>
                        </div>
                    </button>
                </div>
            </div>
        </div>
        <div class="fixed md:hidden top-0 w-screen h-full bg-black/50 backdrop-blur z-30" onclick="openMobileMenu()"></div>
    </div>
    <script>
        function openMobileMenu() {
            document.getElementById("clientsNavBar").classList.toggle("hidden");
        }
    </script>
@endif

