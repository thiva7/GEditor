<x-app-layout title="home">
    <x-success />
    
    @if (config('settings::home_page_text'))
        <div class="content">
            <div class="content-box">
                <div class="prose dark:prose-invert max-w-none">
                    @markdownify(config('settings::home_page_text'))
                </div>
            </div>
        </div>
    @endif

    @if ($categories->count() > 0)
        <div class="content">
            <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('PLANS') }}</h2>
                <p class="text-secondary-600 dark:text-secondary-500">{{ __('Select a category to view available plans') }}</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                @foreach ($categories as $category)
                    @if (($category->products()->where('hidden', false)->count() > 0 && !$category->category_id) || $category->children()->count() > 0)
                        <div class="content-box h-full flex flex-col hover:shadow-lg transition-shadow duration-200">
                            <div class="flex gap-x-3 items-center mb-4">
                                @if($category->image)
                                    <img src="/storage/categories/{{ $category->image }}" class="w-14 h-14 rounded-lg object-cover" onerror="this.style.display='none';" />
                                @endif
                                <div>
                                    <h3 class="font-semibold text-lg text-secondary-900 dark:text-secondary-900">{{ $category->name }}</h3>
                                </div>
                            </div>
                            <div class="prose dark:prose-invert text-sm mb-4 flex-1">
                                @markdownify($category->description)
                            </div>
                            <div class="pt-4 mt-auto">
                                <a href="{{ route('products', $category->slug) }}"
                                    class="button button-primary w-full text-center">
                                    {{ __('Browse Category') }}
                                </a>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    @endif

    <!-- Register bar -->
    @auth
        <div class="content mt-8">
            <div class="content-box text-center">
                <h3 class="text-xl font-semibold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('Welcome back!') }}</h3>
                <p class="text-secondary-600 dark:text-secondary-500 mb-4">{{ __('Manage your services and invoices from your dashboard.') }}</p>
                <a href="{{ route('clients.home') }}" class="button button-primary">
                    {{ __('Go to Dashboard') }}
                </a>
            </div>
        </div>
    @else
        <div class="content mt-8">
            <div class="content-box text-center bg-gradient-to-r from-primary-50 to-primary-100 dark:from-primary-900/20 dark:to-primary-900/10 border-primary-200 dark:border-primary-800">
                <h3 class="text-2xl font-semibold text-secondary-900 dark:text-secondary-900 mb-2">{{ __('Get Started Today') }}</h3>
                <p class="text-secondary-600 dark:text-secondary-500 mb-6">{{ __('Create your account and get your services up and running in no time!') }}</p>
                <a href="{{ route('register') }}" class="button button-primary">
                    {{ __('Create Account') }}
                </a>
            </div>
        </div>
    @endauth

</x-app-layout>

