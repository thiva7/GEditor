const defaultTheme = require("tailwindcss/defaultTheme");

module.exports = {
    darkMode: 'class',
    content: [
        "./vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php",
        './vendor/rappasoft/laravel-livewire-tables/resources/views/**/*.blade.php',
        "./node_modules/flowbite/**/*.js",
        "./storage/framework/views/*.php",
        './app/**/*.php',
        "./resources/views/**/*.blade.php",
        "./themes/default/**/*.{blade.php,js,vue,ts,jsx,tsx}",
        "./themes/professionaltheme/**/*.{blade.php,js,vue,ts,jsx,tsx}",
    ],

    theme: {
        extend: {
            colors: {
                'secondary': {
                    50: 'var(--secondary-50, #ffffff)',
                    100: 'var(--secondary-100, #f9fafb)',
                    200: 'var(--secondary-200, #f3f4f6)',
                    300: 'var(--secondary-300, #e5e7eb)',
                    400: 'var(--secondary-400, #9ca3af)',
                    500: 'var(--secondary-500, #6b7280)',
                    600: 'var(--secondary-600, #4b5563)',
                    700: 'var(--secondary-700, #374151)',
                    800: 'var(--secondary-800, #1f2937)',
                    900: 'var(--secondary-900, #111827)',
                },
                'primary': {
                    50: 'var(--primary-50, #eff6ff)',
                    100: 'var(--primary-100, #dbeafe)',
                    200: 'var(--primary-200, #bfdbfe)',
                    300: 'var(--primary-300, #93c5fd)',
                    400: 'var(--primary-400, #3b82f6)',
                },
                'danger': {
                    50: 'var(--danger-50)',
                    100: 'var(--danger-100)',
                    200: 'var(--danger-200)',
                    300: 'var(--danger-300)',
                    400: 'var(--danger-400)',
                },
                'success': {
                    50: 'var(--success-50)',
                    100: 'var(--success-100)',
                    200: 'var(--success-200)',
                    300: 'var(--success-300)',
                    400: 'var(--success-400)',
                },
            },
            fontFamily: {
                sans: ["Inter", ...defaultTheme.fontFamily.sans],
            },
        },
    },

    variants: {
        extend: {
            opacity: ["disabled"],
        },
    },

    plugins: [require('@tailwindcss/typography'), require('flowbite/plugin'), require('autoprefixer')],
};

