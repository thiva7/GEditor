const path = require('path');

// Check if @tailwindcss/postcss is available (Tailwind v4)
let tailwindPlugin;
try {
    // Try Tailwind v4 first
    tailwindPlugin = require('@tailwindcss/postcss');
} catch (e) {
    // Fallback to Tailwind v3
    try {
        tailwindPlugin = require('tailwindcss')({
            config: path.resolve(__dirname, 'tailwind.config.js'),
        });
    } catch (e2) {
        throw new Error('Neither @tailwindcss/postcss nor tailwindcss could be loaded. Please install one of them.');
    }
}

module.exports = {
    plugins: [
        tailwindPlugin,
        require('autoprefixer'),
    ],
};

