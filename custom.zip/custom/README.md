# Custom Paymenter Theme

A custom theme for Paymenter hosting billing application.

## Structure

```
custom/
├── assets/
│   ├── css/
│   │   └── theme.css          # Theme stylesheet
│   ├── js/
│   │   └── theme.js           # Theme JavaScript
│   └── images/                # Theme images
├── views/
│   ├── layouts/
│   │   └── app.blade.php      # Main layout template
│   └── partials/
│       ├── navigation.blade.php # Navigation partial
│       └── footer.blade.php     # Footer partial
├── lang/                      # Language files (optional)
└── theme.json                 # Theme configuration
```

## Installation

1. Place this theme folder in the `themes` directory of your Paymenter installation
2. The theme should be automatically detected by Paymenter
3. You can activate it through the Paymenter admin panel

## Customization

### Changing Colors

Edit `assets/css/theme.css` and modify the CSS variables:

```css
:root {
    --primary-color: #4f46e5;
    --secondary-color: #7c3aed;
    --accent-color: #06b6d4;
}
```

### Modifying Layout

Edit the Blade templates in the `views/` directory:
- `layouts/app.blade.php` - Main layout structure
- `partials/navigation.blade.php` - Navigation menu
- `partials/footer.blade.php` - Footer content

### Adding Pages

Create new Blade templates in the `views/` directory and reference them in your routes.

## Theme Configuration

Edit `theme.json` to update theme metadata:

```json
{
    "name": "Custom Theme",
    "description": "A custom theme for Paymenter",
    "version": "1.0.0",
    "author": "Your Name",
    "author_url": "https://yourwebsite.com"
}
```

## Notes

- This theme uses Tailwind CSS classes for styling
- Make sure your Paymenter installation has the necessary Blade view helpers
- Test all pages after making changes
- Keep backups of your customizations

## Support

For Paymenter-specific theme documentation, refer to the official Paymenter documentation.

