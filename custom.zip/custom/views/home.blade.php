@extends('theme::layouts.app')

@section('title', 'Home - ' . config('app.name'))

@section('content')
<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <!-- Hero Section -->
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-8">
            <div class="p-6 text-center">
                <h1 class="text-4xl font-bold text-gray-900 mb-4">Welcome to {{ config('app.name', 'Paymenter') }}</h1>
                <p class="text-xl text-gray-600 mb-8">Your trusted hosting billing solution</p>
                <div class="flex justify-center space-x-4">
                    <a href="{{ route('products.index') }}" class="btn-primary">
                        View Products
                    </a>
                    @auth
                        <a href="{{ route('dashboard') }}" class="bg-gray-600 text-white px-6 py-3 rounded-md text-sm font-medium hover:bg-gray-700">
                            Go to Dashboard
                        </a>
                    @else
                        <a href="{{ route('register') }}" class="bg-gray-600 text-white px-6 py-3 rounded-md text-sm font-medium hover:bg-gray-700">
                            Get Started
                        </a>
                    @endauth
                </div>
            </div>
        </div>

        <!-- Features Section -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="card">
                <h3 class="text-xl font-semibold mb-2">Easy Management</h3>
                <p class="text-gray-600">Manage your hosting services with ease through our intuitive interface.</p>
            </div>
            <div class="card">
                <h3 class="text-xl font-semibold mb-2">Secure Payments</h3>
                <p class="text-gray-600">Secure payment processing with multiple payment gateway options.</p>
            </div>
            <div class="card">
                <h3 class="text-xl font-semibold mb-2">24/7 Support</h3>
                <p class="text-gray-600">Get help whenever you need it with our round-the-clock support.</p>
            </div>
        </div>
    </div>
</div>
@endsection

