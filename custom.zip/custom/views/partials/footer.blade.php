<footer class="bg-white border-t border-gray-200 mt-auto">
    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
                <h3 class="text-sm font-semibold text-gray-900 tracking-wider uppercase">Company</h3>
                <ul class="mt-4 space-y-4">
                    <li><a href="#" class="text-base text-gray-500 hover:text-gray-900">About</a></li>
                    <li><a href="#" class="text-base text-gray-500 hover:text-gray-900">Contact</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-gray-900 tracking-wider uppercase">Support</h3>
                <ul class="mt-4 space-y-4">
                    <li><a href="#" class="text-base text-gray-500 hover:text-gray-900">Documentation</a></li>
                    <li><a href="#" class="text-base text-gray-500 hover:text-gray-900">Help Center</a></li>
                </ul>
            </div>
            <div>
                <h3 class="text-sm font-semibold text-gray-900 tracking-wider uppercase">Legal</h3>
                <ul class="mt-4 space-y-4">
                    <li><a href="#" class="text-base text-gray-500 hover:text-gray-900">Privacy Policy</a></li>
                    <li><a href="#" class="text-base text-gray-500 hover:text-gray-900">Terms of Service</a></li>
                </ul>
            </div>
        </div>
        <div class="mt-8 border-t border-gray-200 pt-8">
            <p class="text-base text-gray-400 text-center">
                &copy; {{ date('Y') }} {{ config('app.name', 'Paymenter') }}. All rights reserved.
            </p>
        </div>
    </div>
</footer>

